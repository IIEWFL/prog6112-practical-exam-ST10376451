/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Question1;

/**
 *
 * @author lab_services_student
 */
public class MovieTickets implements IMovieTickets {
    private String[] movies = {"Napoleon", "Oppenheimer"};
    private String[] months = {"JAN", "FEB", "MAR"};
    private int[][] ticketSales = {
        {3000, 1500, 1700}, // Napoleon's sales for JAN, FEB, MAR
        {3500, 1200, 1600}  // Oppenheimer's sales for JAN, FEB, MAR
    };

    // Calculate the total movie sales for a specific movie
    @Override
    public int totalMovieSales(int[] movieTickets) {
        int total = 0;
        for (int tickets : movieTickets) {
            total += tickets;
        }
        return total;
    }

    // Determine the top-performing movie
    @Override
    public String topMovieSales(String[] movies, int[][] totalSales) {
        int maxSales = 0;
        String topMovie = "";
        
        for (int i = 0; i < movies.length; i++) {
            int movieTotal = totalMovieSales(totalSales[i]);
            if (movieTotal > maxSales) {
                maxSales = movieTotal;
                topMovie = movies[i];
            }
        }
        return topMovie;
    }

    // Display the report
    public void displayReport() {
        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.println("----------------------------------");
        
        // Print sales for each month and movie
        for (int i = 0; i < months.length; i++) {
            System.out.printf("%-4s", months[i]);
            for (int j = 0; j < movies.length; j++) {
                System.out.printf("%10d", ticketSales[j][i]);
            }
            System.out.println();
        }
        
        // Calculate total sales for each movie and display
        System.out.println("\nTotal ticket sales:");
        for (int i = 0; i < movies.length; i++) {
            int totalSales = totalMovieSales(ticketSales[i]);
            System.out.printf("%-10s : %d%n", movies[i], totalSales);
        }
        
        // Display the top-performing movie
        String topMovie = topMovieSales(movies, ticketSales);
        System.out.println("\nTop performing movie: " + topMovie);
    }

    // Main method
    public static void main(String[] args) {
        MovieTickets report = new MovieTickets();
        report.displayReport();
    }
}

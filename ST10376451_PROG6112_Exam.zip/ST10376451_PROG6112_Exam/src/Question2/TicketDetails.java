/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Question2;

/**
 
 * @author lab_services_student
 */


public class TicketDetails implements ITicketCalculator {
    private String movieTitle;
    private int ticketCount;
    private double pricePerTicket;
    private final double VAT_RATE = 0.14;

    public TicketDetails(String movieTitle, int ticketCount, double pricePerTicket) {
        this.movieTitle = movieTitle;
        this.ticketCount = ticketCount;
        this.pricePerTicket = pricePerTicket;
    }

    @Override
    public double calculateTotalPrice() {
        return ticketCount * pricePerTicket * (1 + VAT_RATE);  // Calculate price including VAT
    }

    @Override
    public boolean validateTicketData() {
        if (movieTitle == null || movieTitle.isEmpty()) {
            return false;
        }
        if (pricePerTicket <= 0 || ticketCount <= 0) {
            return false;
        }
        return true;
    }

    // Getters
    public String getMovieTitle() { return movieTitle; }
    public int getTicketCount() { return ticketCount; }
    public double getPricePerTicket() { return pricePerTicket; }
}


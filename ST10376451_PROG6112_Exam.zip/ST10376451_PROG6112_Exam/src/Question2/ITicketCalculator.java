/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Question2;

/**
 * ITicketCalculator interface defines the methods for calculating total ticket prices
 * and validating ticket data.
 *
 * @author lab_services_student
 */

public interface ITicketCalculator {
    double calculateTotalPrice();
    boolean validateTicketData();
}


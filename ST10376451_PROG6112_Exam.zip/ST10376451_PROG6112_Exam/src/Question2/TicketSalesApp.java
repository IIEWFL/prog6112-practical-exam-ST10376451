/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Question2;

/**
 *
 * @author lab_services_student
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class TicketSalesApp extends JFrame {
    private JComboBox<String> movieDropdown;
    public JTextField ticketQuantityField;
    public JTextField ticketPriceField;
    private JTextArea reportDisplay;
    private final String[] movies = {"Napoleon", "Oppenheimer", "Damsel"};

    public TicketSalesApp() {
        setTitle("Ticket Sales Application");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2));

        movieDropdown = new JComboBox<>(movies);
        ticketQuantityField = new JTextField();
        ticketPriceField = new JTextField();
        reportDisplay = new JTextArea(5, 20);
        reportDisplay.setEditable(false);

        panel.add(new JLabel("Movie:"));
        panel.add(movieDropdown);
        panel.add(new JLabel("Number of Tickets:"));
        panel.add(ticketQuantityField);
        panel.add(new JLabel("Ticket Price:"));
        panel.add(ticketPriceField);
        panel.add(new JLabel("Ticket Report:"));
        panel.add(new JScrollPane(reportDisplay));

        setJMenuBar(createMenuBar());

        add(panel);
    }

    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitMenuItem);

        JMenuItem processMenuItem = new JMenuItem("Process");
        processMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processTicketSale();
            }
        });
        toolsMenu.add(processMenuItem);

        JMenuItem clearMenuItem = new JMenuItem("Clear");
        clearMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });
        toolsMenu.add(clearMenuItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        return menuBar;
    }

    private void processTicketSale() {
        String movieTitle = (String) movieDropdown.getSelectedItem();
        int ticketCount;
        double pricePerTicket;

        try {
            ticketCount = Integer.parseInt(ticketQuantityField.getText());
            pricePerTicket = Double.parseDouble(ticketPriceField.getText());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for tickets and price.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        TicketDetails ticket = new TicketDetails(movieTitle, ticketCount, pricePerTicket);

        if (!ticket.validateTicketData()) {
            JOptionPane.showMessageDialog(this, "Invalid input data. Please check your entries.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double totalPrice = ticket.calculateTotalPrice();
        String report = "MOVIE TITLE: " + movieTitle + "\n" +
                        "TICKET PRICE: R " + pricePerTicket + "\n" +
                        "NUMBER OF TICKETS: " + ticketCount + "\n" +
                        "TOTAL PRICE: R " + String.format("%.2f", totalPrice);

        reportDisplay.setText(report);
        saveReportToFile(report);
    }

    private void saveReportToFile(String report) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("ticket_report.txt"))) {
            writer.write("MOVIE TICKET REPORT\n");
            writer.write(report);
            JOptionPane.showMessageDialog(this, "Report saved to ticket_report.txt", "Save Successful", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving report.", "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        movieDropdown.setSelectedIndex(0);
        ticketQuantityField.setText("");
        ticketPriceField.setText("");
        reportDisplay.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TicketSalesApp().setVisible(true));
    }
}


    


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import Question2.TicketDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class TicketDetailsTest {

    private TicketDetails ticket;

    public TicketDetailsTest() {
    }

    @BeforeEach
    public void setUp() {
        ticket = new TicketDetails("Napoleon", 3, 100.0);
    }

    @Test
    public void testCalculateTotalPrice_CalculatedSuccessfully() {
        double expectedTotal = 3 * 100.0 * 1.14; // 14% VAT is applied
        double actualTotal = ticket.calculateTotalPrice();
        assertEquals(expectedTotal, actualTotal, 0.01, "Total ticket price calculation is incorrect.");
    }

    @Test
    public void testValidateTicketData_ValidInput() {
        assertTrue(ticket.validateTicketData(), "Validation failed for valid input.");
    }

    @Test
    public void testValidateTicketData_InvalidInput() {
        TicketDetails invalidTicket1 = new TicketDetails("", 3, 100.0); // Empty movie title
        TicketDetails invalidTicket2 = new TicketDetails("Napoleon", 0, 100.0); // Zero tickets
        TicketDetails invalidTicket3 = new TicketDetails("Napoleon", 3, 0); // Zero price

        assertFalse(invalidTicket1.validateTicketData(), "Validation passed for empty movie title.");
        assertFalse(invalidTicket2.validateTicketData(), "Validation passed for zero tickets.");
        assertFalse(invalidTicket3.validateTicketData(), "Validation passed for zero ticket price.");
    }
}

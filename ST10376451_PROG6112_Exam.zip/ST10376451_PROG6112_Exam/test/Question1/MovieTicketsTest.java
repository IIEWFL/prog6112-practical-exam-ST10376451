/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license/default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

package Question1;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class MovieTicketsTest {
    
    private MovieTickets movieTickets;

    public MovieTicketsTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
       
    }
    
    @AfterAll
    public static void tearDownClass() {
       
    }
    
    @BeforeEach
    public void setUp() {
        // Initialize the MovieTickets  before each test
        movieTickets = new MovieTickets();
    }
    
    @AfterEach
    public void tearDown() {
       
        movieTickets = null;
    }

    @Test
    public void testTotalMovieSales_Napoleon() {
        int[] napoleonSales = {3000, 1500, 1700};
        int napoleonTotal = movieTickets.totalMovieSales(napoleonSales);
        assertEquals(6200, napoleonTotal, "Total ticket sales for Napoleon should be 6200");
    }

    @Test
    public void testTotalMovieSales_Oppenheimer() {
        int[] oppenheimerSales = {3500, 1200, 1600};
        int oppenheimerTotal = movieTickets.totalMovieSales(oppenheimerSales);
        assertEquals(6300, oppenheimerTotal, "Total ticket sales for Oppenheimer should be 6300");
    }

    @Test
    public void testTopMovieSales() {
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[][] salesData = {
            {3000, 1500, 1700}, // Napoleon's sales
            {3500, 1200, 1600}  // Oppenheimer's sales
        };
        String topMovie = movieTickets.topMovieSales(movies, salesData);
        assertEquals("Oppenheimer", topMovie, "The top-performing movie is Oppenheimer");
    }
}

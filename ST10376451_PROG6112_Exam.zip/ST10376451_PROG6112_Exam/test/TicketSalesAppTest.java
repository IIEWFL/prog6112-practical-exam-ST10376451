/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import Question2.TicketDetails;
import Question2.TicketSalesApp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


/**
 *
 * @author lab_services_student
 */
public class TicketSalesAppTest {

    private TicketSalesApp app;

    public TicketSalesAppTest() {
    }

    @BeforeEach
    public void setUp() {
        app = new TicketSalesApp();
    }

    @Test
    public void testProcessTicketSale_ValidData() {
        // Simulating user input in the app's fields
        app.ticketQuantityField.setText("3");
        app.ticketPriceField.setText("100.0");

        // Create a mock TicketDetails instance
        TicketDetails ticket = mock(TicketDetails.class);

        // Stub the validateTicketData and calculateTotalPrice methods
        when(ticket.validateTicketData()).thenReturn(true);
        when(ticket.calculateTotalPrice()).thenReturn(3 * 100.0 * 1.14);  // Assuming 14% VAT is applied

        // Simulate the action of processing the ticket sale
        app.movieDropdown.setSelectedIndex(0);  // Select "Napoleon" movie from the dropdown

        // Process the ticket sale
        app.processTicketSale();

        // Verify that the validateTicketData method was called once
        verify(ticket).validateTicketData();

        // Verify that the calculateTotalPrice method was called once
        verify(ticket).calculateTotalPrice();

       
        String reportText = app.reportDisplay.getText();
        assertTrue(reportText.contains("MOVIE TITLE: Napoleon"));
        assertTrue(reportText.contains("TICKET PRICE: R 100.0"));
        assertTrue(reportText.contains("NUMBER OF TICKETS: 3"));
        assertTrue(reportText.contains("TOTAL PRICE: R 342.00"));
    }

    @Test
    public void testProcessTicketSale_InvalidData() {
        // Simulating invalid user input (negative ticket count)
        app.ticketQuantityField.setText("-1");
        app.ticketPriceField.setText("100.0");

        // Simulate the action of processing the ticket sale
        app.processTicketSale();

       
        assertEquals("Please enter valid numbers for tickets and price.", app.getErrorMessage());
    }
}
